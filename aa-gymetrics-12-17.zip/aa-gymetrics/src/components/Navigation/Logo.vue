<template>
  <!--Image is a link to home page-->
  <router-link to="/">
    <!--Stored image-->
    <img src="@/assets/img/logo.png" class="h-16 object-contain" />
  </router-link>
</template>

<script>
export default {
  name: "Logo",
};
</script>
