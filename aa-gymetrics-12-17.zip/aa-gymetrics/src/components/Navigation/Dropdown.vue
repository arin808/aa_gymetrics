<template>
  <div class="flex flex-nowrap">
    <div class="relative inline-flex align-middle w-full font-poppins">
      <!--Dropdown button-->
      <button
        ref="btnDropdownRef"
        class="flex text-white text-lg px-6 py-3 rounded hover:bg-btn-primary-alt w-full bg-btn-primary-blue"
        type="button"
        @click="toggleDropdown()"
      >
        <!--Employee Greeting (will be changed to use Employee name)-->
        Hello User &emsp;
        <div class="flex items-center object-contain h-6 w-6">
          <!--If dropdown is not extended, show arrow down img-->
          <svg
            v-if="!dropdownPopoverShow"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 448 512"
          >
            <!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
            <path
              d="M201.4 374.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 306.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z"
            />
          </svg>
          <!--If dropdown is extended, display arrow up-->
          <svg v-else xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
            <!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
            <path
              d="M201.4 137.4c12.5-12.5 32.8-12.5 45.3 0l160 160c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L224 205.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l160-160z"
            />
          </svg>
        </div>
      </button>
      <!--Enclosing div for logout dropdown button-->
      <div
        ref="popoverDropdownRef"
        :class="{
          hidden: !dropdownPopoverShow,
          block: dropdownPopoverShow,
        }"
        class="text-md z-50 float-left text-right rounded w-full"
      >
        <!--Action button component to logout user-->
        <action-button
          class="h-full w-full"
          text="Logout"
          type="danger"
          @click="LOGOUT"
        />
      </div>
    </div>
  </div>
</template>

<script>
//Imports for dependencies, state properties, mutations, and component
import { createPopper } from "@popperjs/core";
import { mapState, mapMutations } from "vuex";
import { LOGOUT } from "@/store";
import ActionButton from "@/components/Shared/ActionButton.vue";

export default {
  name: "Dropdown",
  components: {
    ActionButton,
  },
  //Local conditional to determine whether dropdown should show or not
  data() {
    return {
      dropdownPopoverShow: false,
    };
  },
  //Use global state property for loggedIn status
  computed: {
    ...mapState(["loggedIn"]),
  },
  //Methods for dropdown and change of state
  methods: {
    //Toggle the dropdown logic to show dropdown menu or not
    toggleDropdown: function () {
      if (this.dropdownPopoverShow) {
        this.dropdownPopoverShow = false;
      } else {
        this.dropdownPopoverShow = true;
        createPopper(this.$refs.btnDropdownRef, this.$refs.popoverDropdownRef, {
          placement: "bottom-start",
        });
      }
    },
    //Use to change loggedIn state
    ...mapMutations([LOGOUT]),
  },
};
</script>
