<template>
  <div></div>
</template>

<script>
//import StudentEntry from "@/components/Employee/StudentEntry.vue";

export default {
  name: "EmployeeLanding",
  components: {},
  data() {
    return {
      students: [],
    };
  },
  async mounted() {},
};
</script>
