<template>
  <div></div>
</template>

<script>
//import ActionButton from "../Shared/ActionButton.vue";
export default {
  name: "StudentEntry",
  components: {},
  props: {
    entry: {
      type: Object,
      required: true,
    },
  },
};
</script>
