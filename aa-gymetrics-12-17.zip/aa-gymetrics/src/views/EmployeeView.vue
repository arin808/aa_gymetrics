<template>
  <div>
    <employee-landing />
  </div>
</template>

<script>
import EmployeeLanding from "@/components/Employee/EmployeeLanding.vue";

export default {
  name: "EmployeeView",
  components: {
    EmployeeLanding,
  },
};
</script>

EmployeeLanding
