<template>
  <div class="w-full h-full p-8 text-lg">
    <!--Header message-->
    <div class="flex font-bold justify-center text-5xl">
      <h1>About AA Gymetrics</h1>
    </div>
    <!--Greeting-->
    <div class="flex-nowrap py-4 font-semibold text-3xl">
      <p>Aloha and welcome to AA Gymetrics.</p>
    </div>
    <!--Main content-->
    <div class="flex-nowrap items-center px-4">
      <p>
        The vision of this website stemmed from an issue that I first
        encountered when I started to go to the gym. As any person who goes to
        the gym at all, would tell you, it's never fun having to wait for a
        machine to open up, or be the person to ask, "How many sets do you have
        left?". One thing I noticed that GCU has, are cameras to view the lines
        for most of the dining options on campus, giving a student an idea of
        how crowded the food options are. That being said, I asked myself, "Why
        doesn't the same thing exist for the gyms?" Of course I'm not suggesting
        we put cameras in the gym, that'd be a bit invasive. But why isn't there
        some other form of displaying the numbers in each gym? This would let
        students trying to get to the gym get an idea of which one they should
        go to, to avoid the crowds. Thus the idea of AA Gymetrics was born. Each
        user has the ability to see the number of people actively checked in to
        each gym, prior to going for a workout. No logins, no registering, just
        quick easy numbers.
        <br />
      </p>
      <!--Closing message-->
      <div class="flex h-full py-4 italic text-3xl">
        <p class="ml-auto">See you in the gym.</p>
      </div>
    </div>
  </div>
</template>
