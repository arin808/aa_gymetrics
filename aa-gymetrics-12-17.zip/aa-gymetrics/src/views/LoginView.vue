<template>
  <p>Login</p>
</template>

<script>
export default {
  name: "LoginView",
};
</script>
