<template>
  <div>
    <!--Self enclosed component tag-->
    <gym-table />
  </div>
</template>

<script>
//Import gym table component
import GymTable from "@/components/Metrics/GymTable.vue";

export default {
  name: "HomeView",
  components: {
    GymTable,
  },
};
</script>
