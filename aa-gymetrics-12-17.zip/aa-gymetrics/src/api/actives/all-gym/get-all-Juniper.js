import axios from "axios";

const getAllJuniper = async () => {
  const response = await axios.get("http://localhost:3000/actives/Juniper");
  return response.data;
};

export default getAllJuniper;
