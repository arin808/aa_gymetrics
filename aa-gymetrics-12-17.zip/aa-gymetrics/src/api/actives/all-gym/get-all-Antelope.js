import axios from "axios";

const getAllAntelope = async () => {
  const response = await axios.get("http://localhost:3000/actives/Antelope");
  return response.data;
};

export default getAllAntelope;
