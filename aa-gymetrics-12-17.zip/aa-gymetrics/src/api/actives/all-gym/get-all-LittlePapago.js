import axios from "axios";

const getAllLittlePapago = async () => {
  const response = await axios.get(
    "http://localhost:3000/actives/Little-Papago"
  );
  return response.data;
};

export default getAllLittlePapago;
