import axios from "axios";

const getAllChaparral = async () => {
  const response = await axios.get("http://localhost:3000/actives/Chaparral");
  return response.data;
};

export default getAllChaparral;
