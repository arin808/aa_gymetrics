import axios from "axios";

const getAllVerdeRiver = async () => {
  const response = await axios.get("http://localhost:3000/actives/Verde-River");
  return response.data;
};

export default getAllVerdeRiver;
