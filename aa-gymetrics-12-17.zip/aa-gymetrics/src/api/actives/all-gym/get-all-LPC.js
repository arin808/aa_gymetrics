import axios from "axios";

const getAllLPC = async () => {
  const response = await axios.get("http://localhost:3000/actives/LPC");
  return response.data;
};

export default getAllLPC;
