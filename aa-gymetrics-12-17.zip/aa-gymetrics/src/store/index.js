import { createStore } from "vuex";

//Export mutations for global use
export const LOGIN = "LOGIN";
export const LOGOUT = "LOGOUT";

//State properties
export const state = () => {
  return {
    loggedIn: false,
  };
};

//Mutations to state properties
export const mutations = {
  //Change state to true
  [LOGIN](state) {
    state.loggedIn = true;
  },
  //Change state to false
  [LOGOUT](state) {
    state.loggedIn = false;
  },
};

//Store object to export
const store = createStore({
  state,
  mutations,
  strict: process.env.NODE_ENV !== "production",
});

export default store;
