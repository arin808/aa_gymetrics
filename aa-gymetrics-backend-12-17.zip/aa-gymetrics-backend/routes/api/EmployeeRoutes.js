//Dependencies and declarations
const { Router } = require("express");
const Employees = require("../../models/Employees");
const router = Router();

//Get employee by ID for login
router.get("/:empID", async (req, res) => {
  try {
    //Find employee using id from request param
    const employee = await Employees.find({
      empID: Number(req.params.empID),
    });
    //If theres no returned result, display error message
    if (!employee) {
      throw new Error("No employee found");
    }
    //If theres a result, update status and return data
    res.status(200).json(employee);
  } catch (error) {
    //Show error message
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
